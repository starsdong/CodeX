class TTMParticle;
class TTMThermalModel;
class TTMThermalModelBSQ;
class TTMThermalFit;
class TF1;
class TF2;

Double_t Norm(Double_t *x, Double_t *par);

Double_t Partition(Double_t *x, Double_t *par);
Double_t CorrPiplus(Double_t *x, Double_t *par);
Double_t CorrPiminus(Double_t *x, Double_t *par);
Double_t CorrKminus(Double_t *x, Double_t *par);
Double_t CorrKplus(Double_t *x, Double_t *par);
Double_t CorrKzero(Double_t *x, Double_t *par);
Double_t CorrAKzero(Double_t *x, Double_t *par);
Double_t CorrProton(Double_t *x, Double_t *par);
Double_t CorrAProton(Double_t *x, Double_t *par);
Double_t CorrNeutron(Double_t *x, Double_t *par);
Double_t CorrANeutron(Double_t *x, Double_t *par);
Double_t CorrLa(Double_t *x, Double_t *par);
Double_t CorrALa(Double_t *x, Double_t *par);
Double_t CorrSigmaplus(Double_t *x, Double_t *par);
Double_t CorrASigmaplus(Double_t *x, Double_t *par);
Double_t CorrSigmaminus(Double_t *x, Double_t *par);
Double_t CorrASigmaminus(Double_t *x, Double_t *par);
Double_t CorrDeltaminus(Double_t *x, Double_t *par);
Double_t CorrADeltaminus(Double_t *x, Double_t *par);
Double_t CorrDeltaplusplus(Double_t *x, Double_t *par);
Double_t CorrADeltaplusplus(Double_t *x, Double_t *par);
Double_t CorrKsiminus(Double_t *x, Double_t *par);
Double_t CorrAKsiminus(Double_t *x, Double_t *par);
Double_t CorrKsi0(Double_t *x, Double_t *par);
Double_t CorrAKsi0(Double_t *x, Double_t *par);
Double_t CorrOmega(Double_t *x, Double_t *par);
Double_t CorrAOmega(Double_t *x, Double_t *par);

Double_t FcnAbsOmega(Double_t *x, Double_t *par);
Double_t FcnArgOmega(Double_t *x, Double_t *par);

Double_t FcnDistr(Double_t *x, Double_t *par);
Double_t FcnDens(Double_t *x, Double_t *par);
Double_t FcnEnergyDens(Double_t *x, Double_t *par);
Double_t FcnEntropyDens(Double_t *x, Double_t *par);
Double_t FcnPressure(Double_t *x, Double_t *par);
Double_t FcnDensWidth(Double_t *x, Double_t *par);
Double_t FcnEnergyDensWidth(Double_t *x, Double_t *par);
Double_t FcnEntropyDensWidth(Double_t *x, Double_t *par);
Double_t FcnPressureWidth(Double_t *x, Double_t *par);
Double_t FcnDensNormWidth(Double_t *x, Double_t *par);
Double_t FcnDensBoltzmannWidth(Double_t *x, Double_t *par);
Double_t FcnEnergyBoltzmannWidth(Double_t *x, Double_t *par);
Double_t FcnEntropyBoltzmannWidth(Double_t *x, Double_t *par);

Double_t IntegrateLegendre32(TF1* func, Double_t a, Double_t b);
Double_t IntegrateLegendre20(TF1* func, Double_t a, Double_t b);
Double_t IntegrateLegendre40(TF1* func, Double_t a, Double_t b);

Double_t IntegrateLaguerre32(TF1* func);
Double_t Integrate2DLaguerre32Legendre32(TF2* func, Double_t ay, Double_t by);

Double_t FindExclVolPressure(TTMThermalModelBSQ *model, Double_t limit);

void Minuit_fcn(Int_t &npar, Double_t *gin, Double_t &f, Double_t *par, 
		Int_t iflag);
void fit_function(TTMThermalModel *mod,char *file,Int_t flag = 0);
